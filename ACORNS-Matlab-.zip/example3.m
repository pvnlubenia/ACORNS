% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    Example 3                                                            %
%                                                                         %
%                                                                         %
% This is an example in Kuwahara et al (2017): A simple two-species       %
%    mass-action reaction system                                          %
%                                                                         %
% RESULT: The network has absolute concentration robustness in 1 species: %
%    A.                                                                   %
%                                                                         %
% Reference: Kuwahara H, Umarov R, Almasri I, Gao X (2017) ACRE: Absolute %
%    concentration robustness exploration in module-based combinatorial   %
%    networks. Synth Biol 2(1):1-6. https://doi.org/10.1093/synbio/ysk01  %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 3';
model = addReaction(model, 'A+B->2B', ...                  % just a visual guide on how the reaction looks like
                           {'A', 'B'}, {1, 1}, [1, 1], ... % reactant species, stoichiometry, kinetic order
                           {'B'}, {2}, [ ], ...            % product species, stoichiometry, "kinetic order" (if reversible)
                           false);                         % reversible or not
model = addReaction(model, 'B->A', ...
                           {'B'}, {1}, [1], ...
                           {'A'}, {1}, [ ], ...
                           false);

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);