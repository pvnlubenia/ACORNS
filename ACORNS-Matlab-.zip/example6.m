% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    Example 6                                                            %
%                                                                         %
%                                                                         %
% This is Example 2.37 in Meshkat et al (2021): A network with only one   %
%    species                                                              %
%                                                                         %
% RESULT: The network does not have a Shinar-Feinberg pair. Hence, the    %
%    algorithm cannot be used.                                            %
%                                                                         %
% Note: The network has absolute concentration robustness in species A.   %
%                                                                         %
% Reference: Meshkat N, Shiu A, Torres A (2021) Absolute concentration    %
%    robustness in networks with low-dimensional stoichiometric subspace. %
%    Vietnam J Math https://doi.org/10.1007/s10013-021-00524-5            %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 6';
model = addReaction(model, 'A->0', ...          % just a visual guide on how the reaction looks like
                           {'A'}, {1}, [1], ... % reactant species, stoichiometry, kinetic order
                           { }, { }, [ ], ...   % product species, stoichiometry, "kinetic order" (if reversible)
                           false);              % reversible or not
model = addReaction(model, 'A->2A', ...
                           {'A'}, {1}, [1], ...
                           {'A'}, {2}, [ ], ...
                           false);
model = addReaction(model, '4A->3A', ...
                           {'A'}, {4}, [4], ...
                           {'A'}, {3}, [ ], ...
                           false);

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);