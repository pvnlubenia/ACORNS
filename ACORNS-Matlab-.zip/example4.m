% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    Example 4                                                            %
%                                                                         %
%                                                                         %
% This is Example 1 in Fortun and Mendoza (2020): Power law approximation %
%    of the pre-industrial carbon cycle model                             %
%                                                                         %
% RESULT: The network has absolute concentration robustness in 1 species: %
%    A2.                                                                  %
%                                                                         %
% Reference: Fortun N, Mendoza E (2020) Absolute concentration robustness %
%    in power law kinetic systems. MATCH Commun Math Comput Chem          %
%    85(3):669-691.                                                       %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 4';
model = addReaction(model, 'A1+2A2<->2A1+A2', ...                 % just a visual guide on how the reaction looks like
                           {'A1', 'A2'}, {1, 2}, [-68, 0.58], ... % reactant species, stoichiometry, kinetic order
                           {'A1', 'A2'}, {2, 1}, [-68, 0.91], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           true);                                 % reversible or not
model = addReaction(model, 'A2<->A3', ...
                           {'A2'}, {1}, [1], ...
                           {'A3'}, {1}, [1], ...
                           true);

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);