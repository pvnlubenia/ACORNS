% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 1                                                                %
%                                                                             %
%                                                                             %
% This is Running Example 2 in [1]: Early STAT signaling network coupled with %
%    the receptor complex formation upon interferon induction                 %
%                                                                             %
% RESULT: The network is of Shinar-Feinberg type but the Shinar-Feinberg      %
%            pairs of deficiency 1 subnetworks have reactant complexes that   %
%            are terminal. This result is different from the one in [1] due   %
%            to the modification discussed in [2].                            %
%                                                                             %
% References                                                                  %
%    [1] Fontanil L, Mendoza E, Fortun N (2021) A computational approach to   %
%           concentration robustness in power law kinetic systems of          %
%           Shinar-Feinberg type. MATCH Commun Math Comput Chem               %
%           86(3):489-516.                                                    %
%    [2] Lao A, Lubenia P, Magpantay D, Mendoza E (2022) Concentration        %
%           robustness in LP kinetic systems. MATCH Commun Math Comput Chem   %
%           88(1):29-66. https://doi.org/10.46793/match.88-1.029L             %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 1';
model.species = { }; % do not fill out; will be filled automatically by 'acr' or 'acr2'
model.reaction(1) = struct('id', 'R1I<->R1', 'reactant', struct('species', {'R1I'}, 'stoichiometry', {1}), 'product', struct('species', {'R1'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(2) = struct('id', 'R2<->R2I', 'reactant', struct('species', {'R2'}, 'stoichiometry', {1}), 'product', struct('species', {'R2I'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1]));
model.reaction(3) = struct('id', 'R2+R1I<->R*', 'reactant', struct('species', {'R2', 'R1I'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [1]));
model.reaction(4) = struct('id', 'R*<->R1+R2I', 'reactant', struct('species', {'R*'}, 'stoichiometry', {1}), 'product', struct('species', {'R1', 'R2I'}, 'stoichiometry', {1, 1}), 'reversible', true, 'kinetic', struct('reactant1', [1], 'reactant2', [1, 1]));
model.reaction(5) = struct('id', 'R*+S2<->R*S2*', 'reactant', struct('species', {'R*', 'S2'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*S2*'}, 'stoichiometry', {1}), 'reversible', true, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [1]));
model.reaction(6) = struct('id', 'R*S2*->R*+S2*', 'reactant', struct('species', {'R*S2*'}, 'stoichiometry', {1}), 'product', struct('species', {'R*', 'S2*'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(7) = struct('id', 'R*S2*+S1->R*S2*S1*', 'reactant', struct('species', {'R*S2*', 'S1'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'R*S2*S1*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(8) = struct('id', 'R*S2*S1*->R*S2*+S1*', 'reactant', struct('species', {'R*S2*S1*'}, 'stoichiometry', {1}), 'product', struct('species', {'R*S2*', 'S1*'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(9) = struct('id', '2S1*->S1*S1*', 'reactant', struct('species', {'S1*'}, 'stoichiometry', {2}), 'product', struct('species', {'S1*S1*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [2], 'reactant2', [ ]));
model.reaction(10) = struct('id', 'S1*S1*->2S1', 'reactant', struct('species', {'S1*S1*'}, 'stoichiometry', {1}), 'product', struct('species', {'S1'}, 'stoichiometry', {2}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));
model.reaction(11) = struct('id', 'S1*+S2*->S1*S2*', 'reactant', struct('species', {'S1*', 'S2*'}, 'stoichiometry', {1, 1}), 'product', struct('species', {'S1*S2*'}, 'stoichiometry', {1}), 'reversible', false, 'kinetic', struct('reactant1', [1, 1], 'reactant2', [ ]));
model.reaction(12) = struct('id', 'S1*S2*->S1+S2', 'reactant', struct('species', {'S1*S2*'}, 'stoichiometry', {1}), 'product', struct('species', {'S1', 'S2'}, 'stoichiometry', {1, 1}), 'reversible', false, 'kinetic', struct('reactant1', [1], 'reactant2', [ ]));

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);