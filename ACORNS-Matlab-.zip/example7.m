% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 7                                                              %
%                                                                           %
%                                                                           %
% This is Example 2.38 in Meshkat et al (2021): A network with two species  %
%                                                                           %
% RESULT: The network has no nontrivial independent decomposition and its   %
%    deficiency is greater than 1. Hence, the algorithm was not able to     %
%    identify absolute concentration robustness in any species.             %
%                                                                           %
% Note: The network has absolute concentration robustness in species A.     %
%                                                                           %
% Reference: Meshkat N, Shiu A, Torres A (2021) Absolute concentration      %
%    robustness in networks with low-dimensional stoichiometric subspace.   %
%    Vietnam J Math https://doi.org/10.1007/s10013-021-00524-5              %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Input the chemical reaction network (see README.txt for details on how to input the network)
model.id = 'Example 7';
model = addReaction(model, 'B->A', ...          % just a visual guide on how the reaction looks like
                           {'B'}, {1}, [1], ... % reactant species, stoichiometry, kinetic order
                           {'A'}, {1}, [ ], ... % product species, stoichiometry, "kinetic order" (if reversible)
                           false);              % reversible or not
model = addReaction(model, 'A+B->2B', ...
                           {'A', 'B'}, {1, 1}, [1, 1], ...
                           {'B'}, {2}, [ ], ...
                           false);
model = addReaction(model, '2A+B->A+2B', ...
                           {'A', 'B'}, {2, 1}, [2, 1], ...
                           {'A', 'B'}, {1, 2}, [ ], ...
                           false);

% Determine the species with absolute concentration robustness
[model, R, F, ACR_species] = acr(model);